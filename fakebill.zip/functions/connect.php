<?php
require $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';
DB::$user = 'fakebill'; // Database user
DB::$password = 'fakebill'; // Database password
DB::$dbName = 'fakebill'; // Database name 
DB::$encoding = 'utf8'; 

